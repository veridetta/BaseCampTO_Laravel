<div class="col-12 row footer">
  <div class="col-sm-3">
    <h3>Tentang BC Tryout</h3>
    <p><a href="#">Tentang Kami</a></p>
    <p><a href="#">Testimonial</a></p>
  </div>
  <div class="col-sm-3">
    <h3>Produk Kami</h3>
    <p><a href="#"><span class="text-bold">Try Out</span> UTBK</a></p>
    <p><a href="#"><span class="text-bold">Try Out</span> SIMAK UI</a></p>
    <p><a href="#">Lainnya</a></p>
  </div>
  <div class="col-sm-3">
    <h3>Hubungi Kami</h3>        
    <h3><a href="#"><i class="fa fa-twitter"></i></a> <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-instagram"></i></a></h3>
    <p><a href="#">FAQ</a></p>
  </div>
  <div class="col-sm-3">
    <h3>BC Tryout</h3>        
    <p>Jl. Pembangunan II Blok D No. 12</p>
  </div>
</div>